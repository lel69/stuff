import random, string, requests
from colorama import Fore
from os import system

proxies = open("proxies.txt").read().splitlines()

def getProxy():
    return random.choice(proxies)
def main():
    woeking = 0
    notworking = 0

    name_first = input("How Should your name start > ")
    name_last = input("How Should your name end > ")
    name_space = int(input("How many letters do you want inbetween your name > "))

    while True:
        firstPart = name_first
        #the best is 2 up
        random_shit = ("").join(random.choice(string.ascii_letters)for k in range(name_space))
        EndPart = name_last
        name = f"{firstPart}{random_shit}{EndPart}"
        checker = requests.get(f"https://auth.roblox.com/v2/usernames/validate?request.username={name}&request.birthday=2000-01-01&request.context=Signup", proxies={"http": 'http://' + getProxy()}).json()
        code1 = checker['message']

        if code1 == "Username is valid":
            woeking+=1
            print("["+Fore.GREEN+"Success"+Fore.WHITE+f"] Allowed {name}")
            system("Success: "+ str(woeking)+ " Success: "+str(notworking))
            with open(name_first + name_last + "Generated", "a") as f:
                f.write(f"{name}\n")
                f.close()
        else:
            notworking+=1
            print("["+Fore.RED+"Failed"+Fore.WHITE+f"] Denied {name}")
            system("Success: "+ str(woeking)+ " Failed: "+str(notworking))
main()