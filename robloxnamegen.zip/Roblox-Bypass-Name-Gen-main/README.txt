pip install requests
pip install colorama

make sure you have the proxies.txt file or it will not open
https://proxyscrape.com/home
here is a place you can go get your proxys i use the http ones
